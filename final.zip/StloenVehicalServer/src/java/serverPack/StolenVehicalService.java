/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serverPack;

import LibPack.Location;
import LibPack.VehicalTrack;
import LibPack.VehicleInfo;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Vector;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.swing.DefaultListModel;
import libpack.PaymentStatus;
import libpack.Transaction;
import libpack.Userdetails;
import pack.Base64;


/**
 *
 * @author OorjaTech
 */
@WebService(serviceName = "StolenVehicalService")
public class StolenVehicalService {

    Connection con;
    Statement stmt;
    String ssql;
    ResultSet rs;
    Transaction trans;
    PaymentStatus pay;
    Transaction data;

    int minSupp, minConf;
    int totalRecords;
    DefaultListModel lmRules;

    DefaultListModel lmSensitive;
    DefaultListModel lmNonSensitive;
    //SingleEntryPort currEntry, currFrom, currTo;
    int maxFromSize;

    Vector<String> ids;
    VehicleInfo vehicleInfo;
    //VehicalTrack vehicalTrack;
    Location location;
    

    private void initDatabase() {
       // String connection = "jdbc:mysql://localhost/smtrolley";
        String connection = "jdbc:mysql://localhost/db14937";
        String user = "root";
        String password = "root";
        String ssql;
         StackTraceElement[] st = Thread.currentThread().getStackTrace();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(connection, user, password);
                System.out.println("Database Connection OK");
        } catch (Exception e) {
            System.out.println("Error opening database : " + e);

        }
    }



    Object stringToObject(String inp) {
        byte b[] = Base64.decode(inp);
        Object ret = null;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(b);
            ObjectInput in = new ObjectInputStream(bis);
            ret = (Object) in.readObject();
            bis.close();
            in.close();
        } catch (Exception e) {
            System.out.println("NOT DE-SERIALIZABLE: " + e);
        }
        return ret;
    }

    String objectToString(Object obj) {
        byte[] b = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutput out = new ObjectOutputStream(bos);
            out.writeObject(obj);
            b = bos.toByteArray();
        } catch (Exception e) {
            System.out.println("NOT SERIALIZABLE: " + e);
        }
        return Base64.encode(b);
    }

 
    @WebMethod(operationName = "getVehicalInfo")
    public String getVehicalInfo(@WebParam(name = "obj") String obj) 
    {
        boolean found= false;
         System.out.println("Start Debugging");
        vehicleInfo = (VehicleInfo)stringToObject(obj);
        //Vector<VehicleInfo> infos = new Vector<VehicleInfo>();
        try {
            initDatabase();
            // get current product
            System.out.println("RFID"+vehicleInfo.rfid);
            ssql = "SELECT * FROM vehicalInfo where  rfid='" + vehicleInfo.rfid+"'";
            System.out.println(ssql);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(ssql);
            if (rs.next()) {
                vehicleInfo = new VehicleInfo();
                vehicleInfo.vid = rs.getInt(1);
                 System.out.println( vehicleInfo.vid);
                vehicleInfo.vno = rs.getString(2);
                  System.out.println( vehicleInfo.vno);
                vehicleInfo.oname = rs.getString(4);
                  System.out.println( vehicleInfo.oname);
                vehicleInfo.mobile = rs.getString(5);
                  System.out.println( vehicleInfo.mobile);
                vehicleInfo.vtype = rs.getString(6);
                  System.out.println( vehicleInfo.vtype);
                  found=true;
                
                //infos.add(vehicleInfo);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        if(found)
        {
        return objectToString(vehicleInfo);
        }
        else{
        
        return null;
        }
        //  System.out.println("vect size: " + vectTrans.size());
        
    
    }

    @WebMethod(operationName = "StolenVehicalLog")
    public String StolenVehicalLog(@WebParam(name = "obj") String obj) {
        //TODO write your implementation code here:
         //Userdetails user = (Userdetails) stringToObject(obj);
        VehicalTrack track=(VehicalTrack)stringToObject(obj);
       initDatabase();
        boolean flag = false;
        try {
            ssql = "insert into stolenvehicallog values('" + track.rfid+ "','" + track.Latitude + "','" + track.Longitude + "','"+track.location+"','"+track.DateTime+"','"+track.SignalID+"')";
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            int i = stmt.executeUpdate(ssql);
            if (i != 0) 
            {
               flag = true;           
            }
       } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return objectToString(flag);
        
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "NormalVehicalLog")
    public String NormalVehicalLog(@WebParam(name = "obj") String obj) {
       VehicalTrack track=(VehicalTrack)stringToObject(obj);
       initDatabase();
        boolean flag = false;
        try {
            ssql = "insert into normalvehicallog values('" + track.rfid+ "','" + track.Latitude + "','" + track.Longitude + "','"+track.location+"','"+track.DateTime+"','"+track.SignalID+"')";
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            int i = stmt.executeUpdate(ssql);
            if (i != 0) 
            {
               flag = true;           
            }
       } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return objectToString(flag);
    }
    
    

    @WebMethod(operationName = "getlocation")
    public String getlocation(@WebParam(name = "obj") String obj) {
        
     boolean found= false;
        System.out.println("Start Debugging");
        location = (Location)stringToObject(obj);
        Vector<Location> infos = new Vector<Location>();
        try {
            initDatabase();
            // get current product
            //System.out.println("RFID"+vehicleInfo.rfid);
            ssql = "SELECT * FROM location";
            System.out.println(ssql);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = stmt.executeQuery(ssql);
            while (rs.next()) {
                 System.out.println("in while loop");
                location = new Location();
                location.Latitude = rs.getString(1);
                 System.out.println( location.Latitude);
                location.Longitude = rs.getString(2);
                  System.out.println( location.Longitude);
                location.location = rs.getString(3);
                  System.out.println( location.location);
                
                  
                
                infos.add(location);
                found=true;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        if(found)
        {
        //return objectToString(location);
            for(int i=0;i<infos.size();i++)
            {
            System.out.println("Location Name "+infos.get(i).location);
            }
                 return objectToString(infos);
                 
                 
        
        }
        else{
        
        return null;
        }
        //  System.out.println("vect size: " + vectTrans.size());
        
    
    }
    
}
