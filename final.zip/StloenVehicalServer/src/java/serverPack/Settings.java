/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serverPack;

/**
 *
 * @author OorjaTech
 */
public class Settings {
    public static String path="G:\\Goraksh17-18\\14730.Trolley\\TrolleyServer";
    public static String suggestedPath="G:\\Goraksh17-18\\14730.Trolley\\Admin";
    
}
