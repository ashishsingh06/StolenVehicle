package com.example.StolenVehicalapp;

import java.io.Serializable;
import java.util.Vector;

public class TempData implements Serializable {
	public String productName;
	public Vector<String> rfidlist;
	public int proQty;
	public double cost,vat=10;
}
