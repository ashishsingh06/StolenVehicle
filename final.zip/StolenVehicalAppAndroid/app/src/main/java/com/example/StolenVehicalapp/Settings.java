package com.example.StolenVehicalapp;

public class Settings {
	public static int SignalID = 1;
	public static String ipaddress="";

}
