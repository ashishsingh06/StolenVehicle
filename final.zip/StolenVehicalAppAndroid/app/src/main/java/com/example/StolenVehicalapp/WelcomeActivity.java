package com.example.StolenVehicalapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.example.StolenVehicalapp.StolenVehicalapp.R;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class WelcomeActivity extends Activity implements LocationListener {
	ViewFlipper viewFlipper;
	Button proceed;
	EditText edip,editlocation;
	//RadioButton signal1,signal2,signal3,signal4;

	static String latitude="10";
	static String longitude="10";
	static String Timing;
	static String formattedDate="Default Time";
	static String address="Default Location";
	CheckBox checkBox;
	String lat;
	String lon;
	String time;
	String add;
	boolean getLatt = false;
	GetLocationTask task;
	Timer t;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
		viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper1);
		viewFlipper.setFlipInterval(900);
		viewFlipper.startFlipping();
		proceed = (Button) findViewById(R.id.btproceed);
		edip = (EditText) findViewById(R.id.edip);
		/*signal1=(RadioButton)findViewById(R.id.signal1);
		signal2=(RadioButton)findViewById(R.id.signal2);
		signal3=(RadioButton)findViewById(R.id.signal3);
		signal4=(RadioButton)findViewById(R.id.signal4);*/
		editlocation=(EditText)findViewById(R.id.editlocation);
		checkBox = (CheckBox) findViewById(R.id.checkBox);

		// Font path
		String fontPath = "fonts/painting the light.ttf";

		// text view label
		TextView txtGhost = (TextView) findViewById(R.id.tvwel);

		// Loading Font Face
		Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);

		// Applying font
		txtGhost.setTypeface(tf);


		proceed.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Settings.ipaddress = edip.getText().toString();
				System.out.println("ipaddress"+Settings.ipaddress );
				if (Settings.ipaddress.isEmpty()) {
					Toast.makeText(getApplicationContext(),"Enter IP Address",Toast.LENGTH_SHORT).show();
					return;
				}
				else if(checkBox.isChecked())
				{
						System.out.println("checkBox"+checkBox.isChecked());
//						latitude=lat;
//						longitude=lon;
//					formattedDate=Timing;
//						address=add;
					setAutolocation();
						System.out.println("lat" + latitude + "long" + longitude + "Time" + Timing + "Add  " + address + "Date " + formattedDate);
					Toast.makeText(getApplicationContext(),"Location name : "+address+"latitude : "+latitude+"longitude : "+longitude +"  updated successfully",Toast.LENGTH_SHORT).show();
				Intent it = new Intent(getApplicationContext(),
						BluetoothConnectActivity.class);
				startActivity(it);
				finish();
					}

//				else if(latitude.equals("")&&longitude.equals("")&&address.equals(""))
//				{
//					latitude="10";
//					longitude="10";
//					address="Defaultlocation";
//					formattedDate="Defaulttime";
//
//					System.out.println("lat" + latitude + "long" + longitude + "Time" + Timing + "Add  " +address + "Date " + formattedDate);
//
//					Intent it = new Intent(getApplicationContext(),
//							BluetoothConnectActivity.class);
//					startActivity(it);
//					finish();
//				}
				else
				{

					//System.out.println("lat" + 50 + "long" + 50 + "Time" + Timing + "Add  " + address + "Date " + formattedDate);
					Toast.makeText(getApplicationContext(),"Location name"+address+"latitude"+latitude+"longitude"+longitude+"  updated successfully",Toast.LENGTH_SHORT).show();
					Intent it = new Intent(getApplicationContext(),
							BluetoothConnectActivity.class);
					startActivity(it);
					finish();
				}
			}
		});




	}
	public void setAutolocation()
	{
		LocationManager lManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
		Location location;

		boolean netEnabled = lManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
		if (netEnabled) {
			lManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
			location = lManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			if (location != null) {

				latitude = "" + location.getLatitude();
				longitude = "" + location.getLongitude();
				time = "" + location.getTime();

				System.out.println("lat" + latitude + "long" + longitude + "Time" + Timing);
				Geocoder gcd = new Geocoder(this, Locale.getDefault());
				List<Address> addresses = null;
				try {
					addresses = gcd.getFromLocation(location.getLatitude(), location.getLongitude(), 2);
					//addresses = gcd.getFromLocation(18.445089,73.868980, 1);
					Address obj = addresses.get(0);
					add = obj.getAddressLine(0);
					//add = add + "\n" + obj.getCountryName();
					//add = add + "\n" + obj.getCountryCode();
					//add = add + "\n" + obj.getAdminArea();
					//add = add + "\n" + obj.getPostalCode();
					//add = add + "\n" + obj.getSubAdminArea();
					add = add + "\n" + obj.getLocality();
					//add = add + "\n" + obj.getSubThoroughfare();


					//add = String.valueOf(obj.getExtras());

				} catch (IOException e) {
					e.printStackTrace();
				}
				if (addresses != null && addresses.size() > 0) {
					//String locality = addresses.get(0).getLocality();


					Calendar c = Calendar.getInstance();
					//System.out.println("Current time =&gt; "+c.getTime());


					SimpleDateFormat df = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
					formattedDate = df.format(c.getTime());
					//formattedDate = ""+c.getTime();
					// Now formattedDate have current date/time
					//System.out.println("Date " + formattedDate);
					Toast.makeText(this, formattedDate, Toast.LENGTH_SHORT).show();
					address=add;
					System.out.println("lat" + latitude + "long" + longitude + "Time" + Timing + "Add  " + add + "Date " + formattedDate);
				}


			}

		}
		else
		{
			buildAlertMessageNoGps();

		}
	}


	public void getlocation(View view)

	{
		//Settings.ipaddress = edip.getText().toString();
		//startActivity(new Intent(WelcomeActivity.this,ShowLocation.class));
		if(checkBox.isChecked())
		{
			Toast.makeText(this,"You have selected auto location mode",Toast.LENGTH_SHORT).show();
		}
		else if(editlocation.getText().toString().equals(""))
		{
			Toast.makeText(this,"Please Enter location name",Toast.LENGTH_SHORT).show();
		}

		else {
			getLatt = true;
			task = new GetLocationTask();
			t = new Timer();
			t.schedule(task, 100, 100);
		}

	}


private void buildAlertMessageNoGps() {
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
				.setCancelable(false)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(final DialogInterface dialog, final int id) {
						startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
					}
				});
////				.setNegativeButton("No", new DialogInterface.OnClickListener() {
////					public void onClick(final DialogInterface dialog, final int id) {
////						dialog.cancel();
////					}
////				});
//		final AlertDialog alert = builder.create();
//		alert.show();
}
		@Override
		public boolean onCreateOptionsMenu (Menu menu){
			// Inflate the menu; this adds items to the action bar if it is present.
			getMenuInflater().inflate(R.menu.welcome, menu);
			return true;
		}

		@Override
		public void onLocationChanged (Location location){

		}

		@Override
		public void onStatusChanged (String s,int i, Bundle bundle){

		}

		@Override
		public void onProviderEnabled (String s){
			Toast.makeText(this, "Enabled new provider " ,
					Toast.LENGTH_LONG).show();



		}

		@Override
		public void onProviderDisabled (String s){
			Toast.makeText(this, "GPS disconnected", Toast.LENGTH_LONG);
			Toast.makeText(getApplicationContext(), "Connected",
					Toast.LENGTH_LONG);


			Toast.makeText(this, "Please Switch on GPS." ,Toast.LENGTH_LONG).show();
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Location Services Not Active");
			builder.setMessage("Please enable Location Services and GPS");
			builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int i) {
					// Show location settings when the user acknowledges the alert dialog
					Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS	);
					startActivity(intent);
				}
			});
			Dialog alertDialog = builder.create();
			alertDialog.setCanceledOnTouchOutside(false);
			alertDialog.show();

		}

	public class GetLocationTask extends TimerTask {

		@Override
		public void run() {
			if (getLatt) {

				getLatt = false;
				Map<String, Double> coords;
				coords =OpenStreetMapUtils.getInstance().getCoordinates(editlocation.getText().toString());

				latitude="" +coords.get("lat");
				longitude="" +coords.get("lon");
				address=editlocation.getText().toString();
				System.out.println("latitude :" + latitude);
				System.out.println("longitude :" + longitude);
			    System.out.println("location name :" + address);
				//Toast.makeText(getApplicationContext(),"Location name"+address+"latitude"+latitude+"longitude"+longitude,Toast.LENGTH_SHORT).show();

			}
		}
	}

	/*public void select_signal_one(View view)
	{
		if(signal1.isChecked())
		{
			Settings.SignalID=1;
			signal2.setChecked(false);
			signal3.setChecked(false);
			signal4.setChecked(false);
		}

	}
	public void select_signal_two(View view)
	{
		if(signal2.isChecked())
		{
			Settings.SignalID=2;
			signal1.setChecked(false);
			signal3.setChecked(false);
			signal4.setChecked(false);
		}
	}
	public void select_signal_three(View view)
	{
		if(signal3.isChecked())
		{
			Settings.SignalID=3;
			signal1.setChecked(false);
			signal2.setChecked(false);
			signal4.setChecked(false);
		}
	}
	public void select_signal_four(View view)
	{
		if(signal4.isChecked())
		{
			Settings.SignalID=4;
			signal1.setChecked(false);
			signal2.setChecked(false);
			signal3.setChecked(false);
		}
	}*/

}
