package com.example.StolenVehicalapp;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Vector;

import LibPack.VehicalTrack;
import LibPack.VehicleInfo;
import libpack.Transaction;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.example.StolenVehicalapp.StolenVehicalapp.R;

public class BluetoothConnectActivity extends Activity {
	private static final String TAG = "BluetoothChat";
	private static final boolean D = true;

	// Message types sent from the BluetoothChatService Handler
	public static final int MESSAGE_STATE_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME = 4;
	public static final int MESSAGE_TOAST = 5;

	public int rfCount = 0, rfData[];
	StringBuilder sb;

	// Key names received from the BluetoothChatService Handler
	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";

	// Intent request codes
	private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
	private static final int REQUEST_ENABLE_BT = 3;

	// Layout Views
	// private TextView mTitle, mContent;

	// Name of the connected device
	private String mConnectedDeviceName = null;

	// String buffer for outgoing messages
	private StringBuffer mOutStringBuffer;
	// Local Bluetooth adapter
	private BluetoothAdapter mBluetoothAdapter = null;
	// Member object for the chat services
	private BluetoothClientService mChatService = null;
	Handler timeHandler;
	Runnable timeRunnable;
	TableLayout table_layout;
	// EditText rowno_et, colno_et;
	// Button build_btn;
	ArrayList<String> columnslist;
	TextView tvrfid;
	private static final String NAMESPACE = "http://serverPack/";
	private static final String URL = "http://"+Settings.ipaddress+":8080/TrolleyServer/TrolleyService?wsdl";
	private static final String SOAP_ACTION = "TrolleyService";
	Vector<Transaction> vecttrans;
	String currentRFID = "";
	Button btstart, btstop;
	Transaction trans;
	VehicleInfo vehicleInfo;
	boolean startFlag = false;
	TextView tvbk, tvtotQty, tvamtToPay, tvPayStatus,tvtype;
	//Vector<Transaction> vectResponse;
	Vector<VehicleInfo> vectResponse;
	Animation animblink;
	int responsevectSize = 0;
	Vector<TempData> vectdata;
	int ColorCnt = 0;
	String suggestion;
	TextView suggestionTextView;
	boolean flag=false;
	VehicalTrack track;
	RadioButton signal1,signal2,signal3,signal4;
	public static int SignalID = 1;
	String Message;
	static double latitude = 10.0;
	static double longitude = 10.0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bluetooth_connect);
		tvrfid = (TextView) findViewById(R.id.tvrfid);
		tvtotQty = (TextView) findViewById(R.id.tvtotqty);
		tvamtToPay = (TextView) findViewById(R.id.tvamtToPay);
		tvPayStatus = (TextView) findViewById(R.id.tvamtStatus);
		tvtype = (TextView) findViewById(R.id.tvtype);
		suggestionTextView=(TextView)findViewById(R.id.tvSuggestProdcuts);
		signal1=(RadioButton)findViewById(R.id.signal1);
		signal2=(RadioButton)findViewById(R.id.signal2);
		signal3=(RadioButton)findViewById(R.id.signal3);
		signal4=(RadioButton)findViewById(R.id.signal4);
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter
				.getDefaultAdapter();

		// If the adapter is null, then Bluetooth is not supported
		if (mBluetoothAdapter == null) {
			Toast.makeText(this, "Bluetooth is not available",
					Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		rfData = new int[12];
		Intent serverIntent = new Intent(this, DeviceListActivity.class);
		startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_INSECURE);
		timeHandler = new Handler(Looper.getMainLooper());
		timeHandler.post(timeRunnable = new Runnable() {
			@Override
			public void run() {
				// timeHandler.removeCallbacks(timeRunnable);
				// return;

				timeHandler.postAtTime(this, SystemClock.uptimeMillis() + 1000);
			}
		});


	vectResponse=new Vector<VehicleInfo>();
		vectdata = new Vector<TempData>();
		responsevectSize = vectResponse.size();


}

	public void select_signal_one(View view)
	{
		if(signal1.isChecked())
		{
			SignalID=1;
			signal2.setChecked(false);
			signal3.setChecked(false);
			signal4.setChecked(false);
		}

	}
	public void select_signal_two(View view)
	{
		if(signal2.isChecked())
		{
			SignalID=2;
			signal1.setChecked(false);
			signal3.setChecked(false);
			signal4.setChecked(false);
		}
	}
	public void select_signal_three(View view)
	{
		if(signal3.isChecked())
		{
			SignalID=3;
			signal1.setChecked(false);
			signal2.setChecked(false);
			signal4.setChecked(false);
		}
	}
	public void select_signal_four(View view)
	{
		if(signal4.isChecked())
		{
			SignalID=4;
			signal1.setChecked(false);
			signal2.setChecked(false);
			signal3.setChecked(false);
		}
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (D)
			Log.d(TAG, "onActivityResult " + resultCode);
		switch (requestCode) {
		case REQUEST_CONNECT_DEVICE_INSECURE:
			// When DeviceListActivity returns with a device to connect
			if (resultCode == Activity.RESULT_OK) {
				connectDevice(data, false);
			}
			break;
		case REQUEST_ENABLE_BT:
			// When the request to eneable Bluetooth returns
			if (resultCode == Activity.RESULT_OK) {
				// Bluetooth is now enabled, so set up a chat session
				setupChat();
			} else {
				// User did not enable Bluetooth or an error occured
				Log.d(TAG, "BT not enabled");
				Toast.makeText(this, R.string.bt_not_enabled_leaving,
						Toast.LENGTH_SHORT).show();
				finish();
			}
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		// Stop the Bluetooth chat services
		if (mChatService != null)
			mChatService.stop();
		if (D)
			Log.e(TAG, "--- ON DESTROY ---");
	}

	@Override
	public void onStart() {
		super.onStart();
		// Toast.makeText(this, "onStart() Started", Toast.LENGTH_SHORT).show();
		if (D)
			Log.e(TAG, "++ ON START ++");

		// If BT is not on, request that it be enabled.
		// setupChat() will then be called during onActivityResult
		if (!mBluetoothAdapter.isEnabled()) {
			Intent enableIntent = new Intent(
					BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
			// Otherwise, setup the chat session
		} else {
			if (mChatService == null)
				setupChat();
		}
		// Toast.makeText(this, "onStart() Ended", Toast.LENGTH_SHORT).show();
	}

	private void connectDevice(Intent data, boolean secure) {
		// Get the device MAC address
		String address = data.getExtras().getString(
				DeviceListActivity.EXTRA_DEVICE_ADDRESS);

		// Get the BLuetoothDevice object
		BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);

		mChatService.connect(device, secure);
	}

	private void setupChat() {
		Log.d(TAG, "setupChat()");

		sb = new StringBuilder();
		// Initialize the BluetoothChatService to perform bluetooth connections
		mChatService = new BluetoothClientService(this, mHandler, 1);

		// Initialize the buffer for outgoing messages
		mOutStringBuffer = new StringBuffer("");
	}

	private void sendMessage(String message) {
		// Check that we're actually connected before trying anything
		if (mChatService.getState() != BluetoothClientService.STATE_CONNECTED) {
			Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT)
					.show();
			return;
		}

		// Check that there's actually something to send
		if (message.length() > 0) {
			// Get the message bytes and tell the BluetoothChatService to write
			byte[] send = message.getBytes();
			mChatService.write(send);

			// Reset out string buffer to zero and clear the edit text field
			mOutStringBuffer.setLength(0);
		}
	}

	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String s = "";
			switch (msg.what) {
			case MESSAGE_STATE_CHANGE:
				if (D)
					Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
				switch (msg.arg1) {
				case BluetoothClientService.STATE_CONNECTED:
					s = getResources().getString(R.string.title_connected_to)
							+ mConnectedDeviceName;
					Toast.makeText(getApplicationContext(), s,
							Toast.LENGTH_SHORT);
					// tvSystemStatus.setText(R.string.title_connected_to);
					// tvSystemStatus.append(mConnectedDeviceName);
					break;
				case BluetoothClientService.STATE_CONNECTING:
					s = getResources().getString(R.string.title_connecting);
					Toast.makeText(getApplicationContext(), s,
							Toast.LENGTH_SHORT);
					// mTitle.setText(R.string.title_connecting);
					break;
				case BluetoothClientService.STATE_LISTEN:
				case BluetoothClientService.STATE_NONE:
					s = getResources().getString(R.string.title_not_connected);
					Toast.makeText(getApplicationContext(), s,
							Toast.LENGTH_SHORT);
					// mTitle.setText(R.string.title_not_connected);
					break;
				}
				break;
			case MESSAGE_WRITE:
				byte[] writeBuf = (byte[]) msg.obj;
				// construct a string from the buffer
				String writeMessage = new String(writeBuf);
				break;
			case MESSAGE_READ:
				byte[] readBuf = (byte[]) msg.obj;
				for (int i = 0; i < msg.arg1; i++) {
					rfData[rfCount++] = readBuf[i];
					sb.append(((char) readBuf[i]));
					if (rfCount == 12) {
						rfCount = 0;
						Toast.makeText(getApplicationContext(),"IP:: "+Settings.ipaddress,Toast.LENGTH_SHORT).show();

						// tvSystemStatus.setText("RFID DETECTED : "
						// + sb.toString());

						currentRFID = sb.toString();
						if(sb.toString().length()==12)
						{
							sb.setLength(0);
						}
						System.out.println("RFID DETECTED : " + sb.toString());
						tvrfid.setText("RFID: " + sb.toString());
						VehicalDetails details=new VehicalDetails();
						details.execute();


						sb = new StringBuilder();
					}
				}

				break;
			case MESSAGE_DEVICE_NAME:
				// save the connected device's name
				mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
				Toast.makeText(getApplicationContext(),
						"Connected to " + mConnectedDeviceName,
						Toast.LENGTH_SHORT).show();
				break;
			case MESSAGE_TOAST:
				Toast.makeText(getApplicationContext(),
						msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
						.show();
				break;
			}
			
		}
	};





	private class VehicalDetails extends AsyncTask<String, Void, String> {


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();


			System.gc();
			vehicleInfo =new VehicleInfo();
			vehicleInfo.rfid=currentRFID;
			System.out.println("Current RFID  :"+vehicleInfo.rfid);


		}

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub

			vehicleInfo= (VehicleInfo) Server.callService(vehicleInfo,
					"getVehicalInfo", "obj");
			flag=true;

			//System.out.println("Result  :"+vectResponse);

			//checkForRepeatProduct();
			//result="success";
			return "";
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			if(vehicleInfo != null) {

				tvtotQty.setText("VID	: " + String.valueOf(vehicleInfo.vid));
				tvamtToPay.setText("Vehical No	: " + String.valueOf(vehicleInfo.vno));
				tvPayStatus.setText("Owner Name : " + String.valueOf(vehicleInfo.oname));
				suggestionTextView.setText("Mobile No : " + String.valueOf(vehicleInfo.mobile));
				tvtype.setText("Vehical Type : " + String.valueOf(vehicleInfo.vtype));
				if(vehicleInfo.vtype.equals("Stolen"))
				{
						latitude =Double.parseDouble(WelcomeActivity.latitude);
						longitude = Double.parseDouble(WelcomeActivity.longitude);
						Message="Your Stolen vehicle was currently passed from this location \n";
					Message+="http://maps.google.com/maps?q=loc:" + String.format("%f,%f", latitude, longitude);
					sendMessage(Message,vehicleInfo.mobile);
					StolenVehicallog stolenVehicallog=new StolenVehicallog();
					stolenVehicallog.execute();
                    	System.out.println("lat" + WelcomeActivity.latitude + "long" + WelcomeActivity.longitude + "Time" + WelcomeActivity.Timing);


				}

				else
				{
					NormalVehicallog normalVehicallog =new NormalVehicallog();
					normalVehicallog.execute();


				}
			}
			else
				{	clear();
					Toast.makeText(BluetoothConnectActivity.this,"This Vehical is Not Registered",Toast.LENGTH_SHORT).show();
				}

		}

	}

	public void clear()
	{
		tvtotQty.setText("" );
		tvamtToPay.setText("");
		tvPayStatus.setText("");
		suggestionTextView.setText("");
		tvtype.setText("");


	}
	public void sendMessage(String msg, String to) {
		try {
			SmsManager smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage(to, null, msg, null, null);
			Toast.makeText(getApplicationContext(), "SMS Sent!",
					Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(),
					"SMS faild, please try again later!",
					Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}

	}




	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.bluetooth_connect, menu);
		return true;
	}
	private class StolenVehicallog extends AsyncTask<String, Void, String> {


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();

			System.gc();
			track =new VehicalTrack();
			track.rfid=currentRFID;
			track.Latitude=WelcomeActivity.latitude;
			track.Longitude=WelcomeActivity.longitude;
            track.location=WelcomeActivity.address;
			track.SignalID=SignalID;
            track.DateTime=WelcomeActivity.formattedDate;
			System.out.println("Vehical Type  :" + track.location);
			System.out.println("Vehical Type  :" + track.DateTime);
			Toast.makeText(getApplicationContext(),""+track.SignalID,Toast.LENGTH_SHORT).show();


		}

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub

			boolean Result =(Boolean)  Server.callService(track,
					"StolenVehicalLog", "obj");
			flag=true;


			return "";
		}



	}
	private class NormalVehicallog extends AsyncTask<String, Void, String> {


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
//			System.gc();
//			trans = new Transaction();
//			trans.bid = Settings.bkid;
//			trans.rfid = currentRFID;

			System.gc();
			track = new VehicalTrack();
			track.rfid = currentRFID;
			track.Latitude = WelcomeActivity.latitude;
			track.Longitude = WelcomeActivity.longitude;
			track.location = WelcomeActivity.address;
			track.SignalID=SignalID;
			track.DateTime = WelcomeActivity.formattedDate;
			Toast.makeText(getApplicationContext(),""+track.SignalID,Toast.LENGTH_SHORT).show();

		}

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub

			boolean Result = (Boolean) Server.callService(track,
					"NormalVehicalLog", "obj");
			flag = true;

			//System.out.println("Result  :"+vectResponse);

			//checkForRepeatProduct();
			//result="success";
			return "";
		}

	}

	/*private class EmergencyVehicallog extends AsyncTask<String, Void, String> {


		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
//			System.gc();
//			trans = new Transaction();
//			trans.bid = Settings.bkid;
//			trans.rfid = currentRFID;

			System.gc();
			track = new VehicalTrack();
			track.rfid = currentRFID;
			track.Latitude = WelcomeActivity.latitude;
			track.Longitude = WelcomeActivity.longitude;
			track.location = WelcomeActivity.address;
			track.SignalID=SignalID;
			track.DateTime = WelcomeActivity.formattedDate;
			Toast.makeText(getApplicationContext(),""+track.SignalID,Toast.LENGTH_SHORT).show();
		}

		@Override
		protected String doInBackground(String... arg0) {
			// TODO Auto-generated method stub

			boolean Result = (Boolean) Server.callService(track,
					"EmergencyVehicalLog", "obj");
			flag = true;

			//System.out.println("Result  :"+vectResponse);

			//checkForRepeatProduct();
			//result="success";
			return "";
		}

	}
*/

}
