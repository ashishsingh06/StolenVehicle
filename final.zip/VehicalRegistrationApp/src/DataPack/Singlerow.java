/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DataPack;

import java.io.Serializable;
import java.util.Vector;


public class Singlerow implements Serializable{
    public Vector<Object> rowData;
    public double lat,longitude,type;
    
    public Singlerow() {
        rowData=new Vector<Object>();
        
    }
    
    
}
