/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DataPack;

import java.io.Serializable;
import java.util.Vector;

public class Db implements Serializable {

    public Vector<Singlerow> allData;
    public Object colName[];
    public int TOTAL_COL;
    double[][] inputFeatures;
    double[] outputFeatures;
    int kVal;

    public Db() {
        allData = new Vector<Singlerow>();
    }

    public void fillFeatures() {
        //System.out.println(" D "+allData.size());
        inputFeatures = new double[allData.size()][3];
        outputFeatures = new double[allData.size()];

        for (int i = 0; i < allData.size(); i++) {
          //  Singlerow sr = allData.get(i);

            inputFeatures[i][0] = Double.parseDouble(allData.get(i).rowData.get(1).toString());
            inputFeatures[i][1] = Double.parseDouble(allData.get(i).rowData.get(2).toString());
            inputFeatures[i][2] = Double.parseDouble(allData.get(i).rowData.get(3).toString());

            outputFeatures[i] = getIndex(allData.get(i).rowData.get(4).toString());
            //System.out.println("  "+inputFeatures[i][0]+"  "+inputFeatures[i][1]+"  "+inputFeatures[i][2] +"   --> "+ outputFeatures[i]);
        }
    }

    int getIndex(String currentBrand) {

        //Vector<String> brandName = new Vector<String>();
//        brandName.add("Bajaj");
//        brandName.add("Hero");
//        brandName.add("Toyota");
//        brandName.add("Hyundai");
//        brandName.add("Royal enfield");
         String []brand ;
        brand= new String[]{"Hero","Toyota","Hyundai","Royalenfield","Bajaj","Mercedes","Toyota","BMW","Hyundai","KTM","Mercedes","Audi","volkswagon","Toyota","volkswagon","Marutisuzuki"};
        Vector<String> brandName = new Vector<String>();
        
        for(int i=0;i<brand.length;i++)
        {
        
          brandName.add(brand[i]);
        }
        int index = 0;
        for (String s : brandName) {
            if (s.equalsIgnoreCase(currentBrand)) {
                return index;

            }
            index++;
        }

        return -1;



    }

    public String predictOutput(int kval,double lat, double lon, double type) {
        this.kVal = kval;
        double errorFinal[][] = new double[inputFeatures.length][3];
        for (int k = 0; k < inputFeatures.length; k++) {
            double currDist =  getDist(inputFeatures[k][0], inputFeatures[k][1], inputFeatures[k][2],lat, lon, type);
            errorFinal[k][0] = currDist;
            errorFinal[k][1] = outputFeatures[k];
            System.out.println("OUT:   "+errorFinal[k][0]+"  "+errorFinal[k][1]);
        }



        //Sort Error array
        for (int i = 0; i < inputFeatures.length; i++) {
            for (int j = i + 1; j < inputFeatures.length; j++) {
                if (errorFinal[i][0] > errorFinal[j][0]) {
                    double temp[] = errorFinal[i];
                    errorFinal[i] = errorFinal[j];
                    errorFinal[j] = temp;
                }
            }
        }
        // Comapare with only Kth neighbour  
        double exactPrice = -1;
        double minDist = 999999999;
        for (int i = 0; i < kVal; i++) {
            if (minDist > errorFinal[i][0]) {
                minDist = errorFinal[i][0];
                exactPrice = errorFinal[i][1];
            }
        }

        String outPut = "";
        for (int i = 0; i < kVal; i++) {
            outPut += errorFinal[i][1] + ",";

        }
        System.out.println("outPut"+outPut);
        return outPut;
    }

    private double getDist(double lat, double lon, double type,
            double clat, double clon, double ctype) {
        double diff = 0;
        // System.out.println("  "+day+" "+src+"  "+dest+"  "+slot+"  "+cDay+"  "+cslot+"   "+cSrc);
        diff = (lat - clat) * (lat - clat) + (lon - clon) * (lon - clon) 
                + (type - ctype) * (type - ctype) ;
        return Math.sqrt(diff);
    }
}
